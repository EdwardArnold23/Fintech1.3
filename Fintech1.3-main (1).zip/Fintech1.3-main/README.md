# Fintech1.3
Class Activity
